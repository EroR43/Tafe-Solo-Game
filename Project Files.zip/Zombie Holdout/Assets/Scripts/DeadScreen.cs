﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Author: Eric Hanks
//Last Edited: 15/04/2020

public class DeadScreen : MonoBehaviour
{
    /// <summary>
    /// a unique identfier for the Animator component within the Unity Engine.
    /// </summary>
    private Animator anim;


    /// <summary>
    /// anim is set to be the Animator component that is attached to the game object that this class is attached to
    /// doing this allows us to use the Animator component's controls to tell an animation to play.
    /// </summary>
    private void Awake()
    {
        anim = GetComponent<Animator>();
    }

    /// <summary>
    /// This DeathScreen function has local bool variable of toggle to be able to tell this method to toggle the death animation.
    /// The bool of the "isAlive" animation is set to be the local bool of this method of toggle,
    /// allowing us to tell the animator to toggle the death screen on and off when the function is called.
    /// </summary>
    /// <param name="toggle"></param>
    public void DeathScreen(bool toggle)
    {
        anim.SetBool("isAlive", toggle);
    }
}
