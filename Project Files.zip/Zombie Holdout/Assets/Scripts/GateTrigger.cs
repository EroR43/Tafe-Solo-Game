﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Made with help from and code from https://www.youtube.com/playlist?list=PLsMV160Duh4xN2xTsS0vytAlBJpagBy_E made by Sykoo
//And from https://www.youtube.com/watch?v=LNLVOjbrQj4&t=598s made by Brackeys
//Last Edited 12/04/2020

public class GateTrigger : MonoBehaviour
{
    /// <summary>
    /// a unique identfier for the Animator component within the Unity Engine.
    /// </summary>
    private Animator anim;

    /// <summary>
    /// anim is set to be the Animator component that is attached to the game object that this class is attached to
    /// doing this allows us to use the Animator component's controls to tell an animation to play.
    /// </summary>
    private void Awake()
    {
        anim = GetComponent<Animator>();
    }

    /// <summary>
    /// This ToggleDoor function has local bool variable of toggle to be able to tell this method to toggle the animation of the gate.
    /// The bool of the "gateClosed" animation is set to be the local bool of this method of toggle,
    /// allowing us to tell the animator to toggle the gates open or closed when the bool is returned.
    /// </summary>
    /// <param name="toggle"></param>
    public void ToggleDoor(bool toggle)
    {
        anim.SetBool("gateClosed", toggle);
    }
}
