﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

//Author: Eric Hanks
//https://www.youtube.com/watch?v=LNLVOjbrQj4&t=598s made by Brackeys
//and https://www.youtube.com/playlist?list=PLy7lD4g7kKGDHdKhlWtZQ_8nGfw6z6yPH made by Immergo Media, AKA Josh.
//Last Edited 12/04/2020

public class Enemy : MonoBehaviour
{
    /// <summary>
    /// a float value for the Enemy's health
    /// </summary>
    public float health;

    /// <summary>
    /// a variable to utilize the position of a external game object(a game object that this script isnt attached to) with a simple identifier.
    /// </summary>
    private Transform currentTarget;
    /// <summary>
    /// A custom identifier for the Unity NavMeshAgent, enabling the easier use of the nav mesh setttings and systems.
    /// </summary>
    private NavMeshAgent agent;

    /// <summary>
    /// a float for the amount of points the player should recieve when killing this enemy.
    /// </summary>
    public float pointsToGive;
    /// <summary>
    /// a unique identfier to allocate the player game object within the Unity system to enable the use of components of said object.
    /// </summary>
    public GameObject player;

    /// <summary>
    /// a float value for the amount of damage the enemy deals to the player when it comes in contact with them.
    /// </summary>
    private float damage = 1f;

    /// <summary>
    /// Within the start function, we set the player variable to be the game object within the unity scene with the tag of "Player".
    /// </summary>
    public void Start()
    {
        player = GameObject.FindWithTag("Player");
    }

    /// <summary>
    /// within the awake function, we set the agent variable to be the NavMeshAgent component that is connected to the enemy game object.
    /// We then call the SetTarget function with parameters that find the gameobject within the unity scene that has the "Player"
    /// tag and use the transform of the found game object
    /// </summary>
    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        SetTarget(GameObject.FindWithTag("Player").transform);
    }

    /// <summary>
    /// Within the Update fuction we call the SetTarget function with the parameter of currentTarget to reset
    /// the target to the new/current position of the target, which would be the player.
    /// The if statement checks to see if the enemy's health has reached 0 yet, running the die method if has reached 0 or below zero.
    /// </summary>
    public void Update()
    {
        SetTarget(currentTarget);
        if(health <= 0)
        {
            Die();
        }
    }

    /// <summary>
    /// This OnCollisionEnter method checks to see whether the collider that the enemy game object has entered has the tag of "Player",
    /// decreasing the currentHealth value of the "Player" class attached to the Player game object, by the damage value defined in this class
    /// and destroying the game object that this instance of the Enemy class is attached to if the collider does belong to the player.
    /// </summary>
    /// <param name="collision"></param>
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            player.GetComponent<Player>().currentHealth -= damage;
            Destroy(this.gameObject);
        }
    }

    /// <summary>
    /// The SetTarget method has a local transform parameter of target that allows
    /// the method to recieve the position of the player from the other methods in way that can be processed easily.
    /// the currentTarget is set to be the transform of the target parameter,
    /// allowing the method to receive the position of the player from outside of this method and utilise it to set the
    /// destination for the NavMeshAgent to the players position, allowing the game object to move towards the
    /// player while following the NavMesh generated in the Unity editor.
    /// </summary>
    /// <param name="target"></param>
    public void SetTarget(Transform target)
    {
        currentTarget = target;
        agent.SetDestination(currentTarget.position);
    }

    /// <summary>
    /// This die function destroys the game object that this instance of the script is attached to
    /// and adds the pointsToGive value in this class to the currentScore value within the Player class,
    /// which is a component of the player game object.
    /// </summary>
    public void Die()
    {
        Destroy(this.gameObject);

        player.GetComponent<Player>().currentScore += pointsToGive;
    }
}
