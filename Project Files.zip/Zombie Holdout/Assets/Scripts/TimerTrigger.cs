﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Author: Eric Hanks
//Made with help and code from https://www.youtube.com/playlist?list=PLy7lD4g7kKGDHdKhlWtZQ_8nGfw6z6yPH made by Immergo Media, AKA Josh.
//Last Edited 15/04/2020

public class TimerTrigger : MonoBehaviour
{
    /// <summary>
    /// a variable to record the time that the player has lived for.
    /// </summary>
    public float timer = 0;
    /// <summary>
    /// a bool to stop the timer from counting up when the player has died
    /// </summary>
    public bool timerEnabled = true;
    /// <summary>
    /// Unique identifier to utilise the HUD class which is a component of the Player game object.
    /// </summary>
    public HUD hud;

    /// <summary>
    /// Unique identifier to utilise the LogReader class that is component that is attached to the same TimerTrigger game object that this script is.
    /// </summary>
    private LogReader reader;
    /// <summary>
    /// a float to be used to record and display the longest survival time of the player.
    /// </summary>
    private float bestTime = 0;

    
    /* This start function is used to set the reader to be the LogReader class that is attached to the TimerTrigger game object as a component so as to make use of the class through a simpler field, 
       it also sets the bestTime float to equal to the bestTime value that has been saved within the Score Log text file by using the reader's LoadFloatByKey function to return the value of the bestTime for that file.
     * The function finally updates the best time UI element with the value that was recieved from the file.*/
    void Start()
    {
        reader = GetComponent<LogReader>();
        bestTime = reader.LoadFloatByKey("bestTime");
        hud.UpdateBestTime(bestTime);
    }

    /* This script uses the update function to check if the timerEnabled bool is true, adding the Time.deltaTime to the timer variable, 
       which means that the timer variable will be equal to the amount of time the game has been running for, and updates the value displayed in the Timer UI element through the HUD.*/
    void Update()
    {
        if(timerEnabled == true)
        {
            timer += Time.deltaTime;
            hud.UpdateTimer(timer);
        }
    }

    /// <summary>
    /// Sets the timerEnabled bool to false, stopping the timer from running, then saves the value of the timer as the new best time if the value is larger than the previous best time or if there is no current best time,
    /// by using log reader class' SaveKeyValuePair function to save the timers value as a string to the key of bestTime.
    /// </summary>
    public void DisableTimer()
    {
        timerEnabled = false;

        if(timer > bestTime)
        {
            reader.SaveKeyValuePair("bestTime", timer.ToString());
            hud.UpdateBestTime(timer);
        }
        else if(bestTime == 0)
        {
            reader.SaveKeyValuePair("bestTime", timer.ToString());
            hud.UpdateBestTime(timer);
        }
    }
}
