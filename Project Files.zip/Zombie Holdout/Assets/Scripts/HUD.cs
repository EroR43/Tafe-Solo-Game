﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Author: Eric Hanks
//Made with help from and code from https://www.youtube.com/playlist?list=PLsMV160Duh4xN2xTsS0vytAlBJpagBy_E made by Sykoo
//And from https://www.youtube.com/watch?v=LNLVOjbrQj4&t=598s made by Brackeys
//https://www.youtube.com/playlist?list=PLy7lD4g7kKGDHdKhlWtZQ_8nGfw6z6yPH made by Immergo Media, AKA Josh.
//Last Edited 15/04/2020

public class HUD : MonoBehaviour
{
    /// <summary>
    /// Allows us to set the Slider UI Element from the Unity Engine as the refrence for the staminaBar within the Unity Inspector.
    /// </summary>
    public Slider staminaBar;
    /// <summary>
    /// Allows us to set the Text UI Element from the Unity Engine as the refrence for the staminaText within the Unity Inspector.
    /// </summary>
    public Text staminaText;
    /// <summary>
    /// Allows us to set the Image UI Element from the Unity Engine as the refrence for the healthImage within the Unity Inspector.
    /// </summary>
    public Image healthImage;

    /// <summary>
    /// Allows us to set the Text UI Element from the Unity Engine as the refrence for the scoreText within the Unity Inspector.
    /// </summary>
    public Text scoreText;
    /// <summary>
    /// Allows us to set the Text UI Element from the Unity Engine as the refrence for the highScoreText within the Unity Inspector.
    /// </summary>
    public Text highScoreText;
    /// <summary>
    /// Allows us to set the Text UI Element from the Unity Engine as the refrence for the timerText within the Unity Inspector.
    /// </summary>
    public Text timerText;
    /// <summary>
    /// Allows us to set the Text UI Element from the Unity Engine as the refrence for the bestTimeText within the Unity Inspector.
    /// </summary>
    public Text bestTimeText;

    /// <summary>
    /// A method that updates the diplay of the stamina UI elements with the current values for stamina,
    /// by setting the staminaBar's value as a slider, to equal what the currentStamina value that is within the Player class,
    /// dividing that value by 10 so it can used in the decimal format that the slider uses.
    /// The text for the stamina value is the same currentStamina value as in the previous sentence,
    /// is converted into a string that does not contain the original decimal value present in the currentStamina variable,
    /// with a forward slash added in front of the string for visual purposes,
    /// and the maxStamina value from the same Player class.
    /// </summary>
    /// <param name="stats"></param>
    public void UpdateStamina(Player stats)
    {
        staminaBar.value = stats.currentStamina / 10;
        staminaText.text = stats.currentStamina.ToString("0") + " / " + stats.maxStamina;
    }

    /// <summary>
    /// A method to update the UI element's diplay of the players current health
    /// by setting the fill amount of the healthImage to equal the value of currentHealth variable from the Player class,
    /// but dividing that value by 3 to be able to fit the decimal format required by the image.
    /// </summary>
    /// <param name="stats"></param>
    public void UpdateHealth(Player stats)
    {
        healthImage.fillAmount = stats.currentHealth / 3;
    }

    /// <summary>
    /// A method to update the current score UI in the game,
    /// updating the scoreText with the current value for the currentScore variable within the Player class,
    /// converting the value into a string to be used in the text box.
    /// For stylistic choices, it is set to read "Score: 200" with the 200 being the currentScore value.
    /// </summary>
    /// <param name="stats"></param>
    public void UpdateScore(Player stats)
    {
        scoreText.text = "Score: " + stats.currentScore.ToString();
    }

    /// <summary>
    /// Updates the UI element with the time that has elapsed since the game has begun,
    /// by using a local float so the method can be passed the elapsed time calculated within the FormatFloatAsTime string with the parameter of time.
    /// </summary>
    /// <param name="time"></param>
    public void UpdateTimer(float time)
    {
        timerText.text = "Timer: " + FormatFloatAsTime(time);
    }

    /// <summary>
    /// Updates the highScoreText UI element with the value that is recieved from the highscore recorded in the Score Log text file,
    /// which is recorded after every death within the game.
    /// This function is also used in the event that the players current score exceeds the highscore, overwriting the high score.
    /// </summary>
    /// <param name="highScore"></param>
    public void UpdateHighScore(float highScore)
    {
        highScoreText.text = "High Score: " + highScore;
    }

    /// <summary>
    /// Updates the bestTimeText UI element with the best time that is recorded in the same Score Log text file as the high score,
    /// uses the local float of bestTime so it can have the bestTime passed to it from the TimerTrigger class.
    /// The bestTime value is converted to an appropriate format to be used in a text UI element throught the FormatFloatAsTime string,
    /// using the bestTime parameter.
    /// </summary>
    /// <param name="bestTime"></param>
    public void UpdateBestTime(float bestTime)
    {
        bestTimeText.text = "Time to Beat: " + FormatFloatAsTime(bestTime);
    }

    /// <summary>
    /// This string converts the raw time values in seconds and milliseconds that it is passed through its time parameter into a proper format for displaying time in minutes and seconds,
    /// rounding the values into whole numbers by converting them to an integer.
    /// The calculations by themselves are relatively simple, the time that the string is passed is divided by 60 to convert the seconds into minutes, 
    /// with the result being passed through the Mathf FloorToInt function to round down the result to the closest minute and the result is finally saved as the minutes int.
    /// This minutes int is then used to determine how many seconds are left over from the raw value,
    /// by subtracting the result of the minutes value being multiplied by 60 from the raw value of time, giving the leftover seconds that cant be converted into minutes,
    /// that value is then passed through the FloorToInt function again to be converted into the lowest whole number value and is saved as the seconds integer.
    /// Now the timeTag string is then formatted and defined to display the two different variables with a colon seperating the two.
    /// This timeTag variable is the final value that the string will return when it is called.
    /// </summary>
    /// <param name="time"></param>
    /// <returns></returns>
    public string FormatFloatAsTime(float time)
    {
        int minutes = Mathf.FloorToInt(time / 60);
        int seconds = Mathf.FloorToInt(time - minutes * 60);
        string timeTag = string.Format("{0:00}:{1:00}", minutes, seconds);
        return timeTag;
    }
}
