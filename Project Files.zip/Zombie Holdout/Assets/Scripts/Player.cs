﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Author: Eric Hanks
//Made with help and code from https://www.youtube.com/playlist?list=PLsMV160Duh4xN2xTsS0vytAlBJpagBy_E made by Sykoo
//And from https://www.youtube.com/watch?v=LNLVOjbrQj4&t=598s made by Brackeys
//and https://www.youtube.com/playlist?list=PLy7lD4g7kKGDHdKhlWtZQ_8nGfw6z6yPH made by Immergo Media, AKA Josh.
//Last Edited 15/04/2020

public class Player : MonoBehaviour
{
    //Variables

    /// <summary>
    /// the max speed the player can walk within the game. 
    /// </summary>
    public float movementSpeed = 5f;
    /// <summary>
    /// how fast the player can move when they are sprinting.
    /// </summary>
    public float sprintSpeed = 10f;
    /// <summary>
    /// the current speed that the player is moving
    /// </summary>
    private float currentSpeed = 0f;

    /// <summary>
    /// max amount of stamina the player can use to sprint
    /// </summary>
    public float maxStamina = 10;
    /// <summary>
    /// the current stamina that the player has.
    /// </summary>
    public float currentStamina;
    
    /// <summary>
    /// the max amount of health the player can have.
    /// </summary>
    public float maxHealth = 3f;
    /// <summary>
    /// the current health that the player has.
    /// </summary>
    public float currentHealth;

    /// <summary>
    /// the current score that the player has accumulated by killing enemies
    /// </summary>
    public float currentScore;
    /// <summary>
    /// a field to make use of the LogReader class's functions and variables with a simple name.
    /// </summary>
    public LogReader scoreReader;
    /// <summary>
    /// the highest score that the player has achieved by killing enemies
    /// </summary>
    private float highScore = 0;
    /// <summary>
    /// field to make refrence and use of the camera game object within the unity scene
    /// </summary>
    public new GameObject camera;

    //  Named and configurable keyboard controls, allows the ability to set Keyboard buttons for certain uses.
    public KeyCode sprintKey, intKey;

    /// <summary>
    /// allows us to manipulate the rotation and position of the player game object in the unity scene
    /// </summary>
    public GameObject playerObj;

    /// <summary>
    /// allows us to refrence and utilise the bullet spawn point game object's position and rotation
    /// </summary>
    public GameObject bulletSpawnPoint;
    /// <summary>
    /// allows us to instantiate the bullet prefab in the unity assets folder.
    /// </summary>
    public GameObject bullet;
    
    /// <summary>
    /// used for sprint mechanics to detect if you are moving in a direction to avoid draining stamina when standing still.
    /// </summary>
    public int keyPress = 0;

    /// <summary>
    /// the max distance the ray cast can project out from the player game object.
    /// </summary>
    public float distance = 1.5f;

    /// <summary>
    /// used to stop movement when the player dies.
    /// </summary>
    public bool isAlive;

    /// <summary>
    /// allows us to use the HUD class's functions and variables to update and set the UI elements in the game.
    /// </summary>
    public HUD hud;
    /// <summary>
    /// allows us to use TimerTrigger class's functions and variables to update the elapsed play time, stop then timer when the player dies and to save the best time.
    /// </summary>
    public TimerTrigger timer;

    /// <summary>
    /// allows us to use the DeadScreen class's functions to activate the death screen upon death.
    /// </summary>
    public DeadScreen dead;

    //Methods

    /* This start function is used to set up the essential mechanics of the game, getting the HUD component for use in running the UpdateHealth, UpdateStamina and the UpdateScore functions to 
     * setup and update their respective UI elements. It sets the currentHealth to equal the maxHealth, the currentScore to equal 0, the currentSpeed to be the movementSpeed, 
     * the currentStamina to equal the maxStamina and the isAlive bool to be true
     * It also loads the highScore recorded in the Score Log text file to update the UI with this value.*/
    public void Start()
    {
        hud = GetComponent<HUD>();
        currentHealth = maxHealth;
        currentScore = 0;
        currentSpeed = movementSpeed;
        currentStamina = maxStamina;
        isAlive = true;
        hud.UpdateHealth(this);
        hud.UpdateStamina(this);
        hud.UpdateScore(this);
        highScore = scoreReader.LoadFloatByKey("highScore");
        hud.UpdateHighScore(highScore);
    }


    // This update function's code is almost entirely encapsulated by an 'isAlive equals true' if statement, stopping all the code within from executing if it is ever set to false.
    void Update()
    {
        if(isAlive == true)
        {

            /* Player facing mouse: this block of code is dedicated to making the player game object to rotate to face the position of the mouse within the scene through the use of raycasts, planes and cameras.
             * It uses the position of the mouse pointer in the cameras fov to calculate where the player should rotate to. */
            Plane playerPlane = new Plane(Vector3.up, transform.position);
            Ray ray = UnityEngine.Camera.main.ScreenPointToRay(Input.mousePosition);
            if (playerPlane.Raycast(ray, out float hitDist))
            {
                Vector3 targetPoint = ray.GetPoint(hitDist);
                Quaternion targetRotation = Quaternion.LookRotation(targetPoint - transform.position);
                targetRotation.x = 0;
                targetRotation.z = 0;
                playerObj.transform.rotation = Quaternion.Slerp(playerObj.transform.rotation, targetRotation, 7f * Time.deltaTime);


            }

            //Player Movement: This block is just movement
            PlayerMovement();
            Sprint();

            //UI: The functions of this block of code update the values that are diplayed in the HUD to make sure that they are correctly representing the actual values of the player stats during every frame of play.
            hud.UpdateHealth(this);
            hud.UpdateStamina(this);
            hud.UpdateScore(this);

            //Shooting: This if function only runs when the player left clicks, running the Shoot function. This is shooting.
            if (Input.GetMouseButtonDown(0))
            {
                Shoot();
            }

            //Stamina: This block of code ensures that the players stamina never exceedes the max stamina value.
            if (currentStamina >= maxStamina)
            {
                currentStamina = maxStamina;
            }

            //Interaction: This code runs the interaction script when the interaction key is pressed.
            if (Input.GetKey(intKey) == true)
            {
                DetectInteraction();
            }
            //Dieing: This if statement initiates the players death in the event that their health reaches 0.
            if (currentHealth <= 0f)
            {
                StartCoroutine(Die());
            }
        }
        //Quit Game: Quits the game when the escape key is pressed.
        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    /// <summary>
    /// Shoots bullets out from the front of the player by instantiating the bullet prefab, where the bullet class does the rest.
    /// </summary>
    void Shoot()
    {
        Instantiate(bullet.transform, bulletSpawnPoint.transform.position, bulletSpawnPoint.transform.rotation);

    }

    /// <summary>
    /// Changes the players current speed to the sprint speed if the player has the sprint button held down, is moving in a direction and has the stamina to do so.
    /// This also drains the players stamina only when they are sprinting,
    /// initiating the StaminaRecharge coroutine if the players stamina is less than the max stamina and isnt sprinting.
    /// </summary>
    void Sprint()
    {
        if (Input.GetKey(sprintKey) == true && keyPress != 0)
        {
            if (currentStamina >= 0)
            {
                currentSpeed = sprintSpeed;
                currentStamina -= 3 * Time.deltaTime;
            }

            else
            {
                currentSpeed = movementSpeed;
            }
        }
        else if (currentStamina <= 10)
        {
            StartCoroutine(StaminaRecharge());
            currentSpeed = movementSpeed;
        }
        if (currentStamina <= 0)
        {
            currentStamina = 0;
        }
    }

    /// <summary>
    /// Waits 2 seconds from when it is called then starts increasing the current stamina by 1 every frame.
    /// </summary>
    /// <returns></returns>
    IEnumerator StaminaRecharge()
    {
        yield return new WaitForSeconds(2f);
        currentStamina += 1f * Time.deltaTime;
    }

    /// <summary>
    /// This function was the result of a convoluted problem with the sprint mechanic,
    /// that being that the stamina was being used up while holding the sprint key even if you were standing still.
    /// To resolve that, each directional movement has a keyPress value and the sprint only fuctions when that keyPress value is greater than 0.
    /// Other than that, pretty standard movemtent, hold W, move forwards, hold S, move backwards, hold A, move left, hold D, move right.
    /// </summary>
    void PlayerMovement()
    {
        keyPress = 0;
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(Vector3.forward * currentSpeed * Time.deltaTime);
            keyPress = 1;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.back * currentSpeed * Time.deltaTime);
            keyPress = 2;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.left * currentSpeed * Time.deltaTime);
            keyPress = 3;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * currentSpeed * Time.deltaTime);
            keyPress = 4;
        }
    }
    /// <summary>
    /// The Coroutine for dying. Prints "You Died" in the unity console, stops the timer, runs the SaveHighScore function, sets isAlive to false,
    /// it then waits for 10 seconds while the zombie hord surrounds you and then plays the Death Screen animation and waits another 10 seconds before closing the application.
    /// </summary>
    /// <returns></returns>
    IEnumerator Die()
    {
        print("You Died");
        timer.DisableTimer();
        SaveHighScore();
        isAlive = false;
        yield return new WaitForSecondsRealtime(10f);
        DeadScreen d = dead.GetComponent<DeadScreen>();
        Animator anim = dead.GetComponent<Animator>();
        d.DeathScreen(!anim.GetBool("isAlive"));
        yield return new WaitForSecondsRealtime(10f);
        Application.Quit();
    }

    /// <summary>
    /// Raycasts a ray out from the current position and forward orientation of the player at a range of 1.5 meters and if that ray hits something,
    /// checks whether the object it hit was the game object with the Gate tag, Drawing the ray in a green colour and running the ToggleDoor function fo the GateTrigger's class.
    /// If it doesnt hit anything, it will print a message in the console stating that it didnt and draw a red ray.
    /// </summary>
    void DetectInteraction()
    {
        if (Physics.Raycast(playerObj.transform.position, playerObj.transform.forward, out RaycastHit hit, distance) == true)
        {
            if (hit.transform.CompareTag("Gate"))
            {
                GateTrigger d = hit.transform.GetComponent<GateTrigger>();
                Debug.DrawRay(playerObj.transform.position, playerObj.transform.forward * distance, Color.green, 0.2f);
                Animator anim = hit.transform.GetComponent<Animator>();
                d.ToggleDoor(!anim.GetBool("gateClosed"));
            }
        }
        else
        {
            Debug.Log("Did not hit interactive");
            Debug.DrawRay(playerObj.transform.position, playerObj.transform.forward * distance, Color.red, 0.2f);
        }
        
    }

    /// <summary>
    /// Checks if the currentScore is greater than the highScore recieved from the Score Log txt and saves the currentScore value as the new highScore in said txt if it is,
    /// Updating the high score HUD with the new value.
    /// </summary>
    public void SaveHighScore()
    {
        if(currentScore > highScore)
        {
            scoreReader.SaveKeyValuePair("highScore", currentScore.ToString());
            hud.UpdateHighScore(currentScore);
        }
    }
}
