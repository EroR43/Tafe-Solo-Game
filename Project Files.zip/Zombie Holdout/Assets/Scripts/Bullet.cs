﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Author: Eric Hanks
//Made with help from and code from https://www.youtube.com/playlist?list=PLsMV160Duh4xN2xTsS0vytAlBJpagBy_E made by Sykoo
//And from https://www.youtube.com/watch?v=LNLVOjbrQj4&t=598s made by Brackeys
//Last Edited 11/04/2020

public class Bullet : MonoBehaviour
{
    /// <summary>
    /// Float variable for the bullet's movement speed.
    /// </summary>
    public float speed;
    /// <summary>
    /// Float variable for the max distance that the bullet can travel before being destroyed.
    /// </summary>
    public float maxDist;

    /// <summary>
    /// A Class from another entity, set with a memorable name that can be used to alter values and call functions within of the other class.
    /// </summary>
    private GameObject triggeringEnemy;
    /// <summary>
    /// float variable to designate how much damage will be dealt to the enemy when the bullet hits its target,
    /// set with a public protect level and without a value as to ease the changing of the value within the unity inspector.
    /// </summary>
    public float damage;

    /// <summary>
    /// within the update function, the movement of the bullet is defined.
    /// The bullet moves forward at a constant speed,
    /// updating its position frame by frame according to the time between the last frame and the current one,
    /// moving forward from where it is instantiated, being from the location and following the orientation of the Bullet Spawn Point object in the Unity Scene.
    /// The maxDist variable is increased by + 1 every frame.
    /// A check is preformed everyframe to check if the maxDist variable's value is greater than 3,
    /// destroying the bullet gameobject that this script is attached to if it is.
    /// </summary>
    void Update()
    {
        transform.Translate(Vector3.forward * Time.deltaTime * speed);
        maxDist += 1 * Time.deltaTime;

        if (maxDist >= 3)
            Destroy(this.gameObject);
    }

    /// <summary>
    /// On the event that the bullet enters the collision of a game object within the unity scene, this function will run.
    /// This function will check the game object of the collider that the bullet enter for the "Enemy" tag,
    /// it will then identify/set the game object that the collider belongs to as the triggeringEnemy GameObject,
    /// allowing us to get the gameobjects Enemy class component and alter the health variable within that class,
    /// subtracting the damage value in this class from the health variable in the Enemy class.
    /// The game object that this script is attached will then be destroyed after hitting the enemy's collider.
    /// If the bullet enters a collider that doesnt have game object with the "Enemy" tag, the bullet that this script is attached to will be destroyed,
    /// without influencing the Enemy gameobject.
    /// </summary>
    /// <param name="collision"></param>
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            triggeringEnemy = collision.gameObject;
            triggeringEnemy.GetComponent<Enemy>().health -= damage;
            Destroy(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
        }
    }
}
