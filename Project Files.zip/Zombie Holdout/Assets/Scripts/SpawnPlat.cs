﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Author: Eric Hanks
//Last Edited 15/04/2020

public class SpawnPlat : MonoBehaviour
{
    /// <summary>
    /// The game object we wish to spawn
    /// </summary>
    public GameObject enemy;
    /// <summary>
    /// the position and rotation of the spawn platforms within the Unity scene
    /// </summary>
    public Transform spawnPlat;
    /// <summary>
    /// The amount of ticks before an enemy is spawned
    /// </summary>
    public int maxTickCount;
    /// <summary>
    /// the ammount of ticks that have passed
    /// </summary>
    public int currentTickCount;
    /// <summary>
    /// an field to make use of the Player class's functions.
    /// </summary>
    public Player player;

    // This start function runs the SetUpTicks function, thats it.
    public void Start()
    {
        SetUpTicks();
    }

    // This update function runs the UpdateTicks function and runs the OnDeathTicks function if the isAlive bool from the Player class is equal to false.
    public void Update()
    {
        UpdateTicks();
        if (player.isAlive == false)
        {
            OnDeathTicks();
        }

    }

    /// <summary>
    /// Instantiates a Enemy game object where the spawnPlat's position is within the Unity scene and with the normal rotation of the player game object to avoid improper scaling.
    /// </summary>
    public void SpawnEnemy()
    {
        Instantiate(enemy.transform, spawnPlat.position, enemy.transform.rotation);
    }

    /// <summary>
    /// Sets the maxTickCount to 300 and the currenTickCount to equal the maxTickCount.
    /// </summary>
    public void SetUpTicks()
    {
        maxTickCount = 300;
        currentTickCount = maxTickCount;
    }

    /// <summary>
    /// Runs the SpawnEnemy function, sets currentTickCount to 0 and reduces the maxTickCount by five on the condition that the currentTickCount has reached the value of the maxTickCount or has gone over,
    /// otherwise, it adds 1 to the currentTickCount.
    /// This creates a loop of the currentTickCount counting up to the maxTickCount then being set back to 0 but with the maxTickCount reduced, meaning the spawning of enemyies grows faster and faster.
    /// </summary>
    public void UpdateTicks()
    {
        if (currentTickCount == maxTickCount | currentTickCount >= maxTickCount)
        {
            SpawnEnemy();
            currentTickCount = 0;
            maxTickCount -= 5;
        }
        else
        {
            currentTickCount += 1;
        }
    }

    /// <summary>
    /// Sets the maxTickCount to 0, causing enemies to spawn rapidly and swarm the player.
    /// </summary>
    public void OnDeathTicks()
    {
        maxTickCount = 0;
    }
}
